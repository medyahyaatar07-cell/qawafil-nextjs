-- Qawafil Al Khair — admin-panel backend, on Supabase.
--
-- This replaces the Claude Artifact database the admin panel originally
-- used (window.claude.use("db")), so the page can be hosted anywhere and
-- still have a working password gate + photo manager.
--
-- Design: two generic tables that mirror the shape the page's JavaScript
-- already speaks (Firestore-style "doc" and "collection" paths), so the
-- admin panel's logic didn't need to be rewritten — only the transport
-- underneath it changed. See qawafil_live_base2.html's SUPABASE_URL /
-- SUPABASE_ANON_KEY constants and the adapter right below them.
--
-- Security note (carried over, unchanged, from the original build): there
-- is no real user-account system here — one shared admin password gates
-- the UI. The tables below are readable and writable by anyone who can
-- reach your Supabase project's public API (this is normal for a
-- browser-only app using the anon key), so the password is a UI
-- convenience, not a hard security boundary. Don't store anything here
-- you wouldn't be comfortable with a determined visitor eventually
-- reading or overwriting. This is the same trade-off the site already
-- had; nothing here makes it weaker.

-- ---------------------------------------------------------------------
-- 1) Generic "document" table — one row per (admin_auth/config,
--    field_hidden/<key>) path.
-- ---------------------------------------------------------------------
create table if not exists kv_docs (
  path        text primary key,
  data        jsonb not null,
  updated_at  timestamptz not null default now()
);

alter table kv_docs enable row level security;

-- Anyone can read (needed to check "is a password already set?" and to
-- show the current hidden-photos list on the public gallery).
create policy "kv_docs_select_anon" on kv_docs
  for select to anon using (true);

-- Anyone can create/update a row. The admin panel's own client-side
-- password check is what actually gates this in the UI — see the
-- security note above.
create policy "kv_docs_upsert_anon" on kv_docs
  for insert to anon with check (true);
create policy "kv_docs_update_anon" on kv_docs
  for update to anon using (true) with check (true);
create policy "kv_docs_delete_anon" on kv_docs
  for delete to anon using (true);

-- ---------------------------------------------------------------------
-- 2) Generic "collection item" table — one row per uploaded photo, e.g.
--    collection_path = "field_photos/01/images".
-- ---------------------------------------------------------------------
create table if not exists kv_collection_items (
  id               uuid primary key default gen_random_uuid(),
  collection_path  text not null,
  data             jsonb not null,
  created_at       timestamptz not null default now()
);

create index if not exists kv_collection_items_path_idx
  on kv_collection_items (collection_path);

alter table kv_collection_items enable row level security;

create policy "kv_items_select_anon" on kv_collection_items
  for select to anon using (true);
create policy "kv_items_insert_anon" on kv_collection_items
  for insert to anon with check (true);
create policy "kv_items_delete_anon" on kv_collection_items
  for delete to anon using (true);

-- ---------------------------------------------------------------------
-- 3) Realtime — so the public gallery updates live when the admin adds
--    or hides a photo, without a page refresh (same behavior as before).
-- ---------------------------------------------------------------------
alter publication supabase_realtime add table kv_docs;
alter publication supabase_realtime add table kv_collection_items;

-- ---------------------------------------------------------------------
-- 4) Storage bucket for the actual photo files.
--    (Run this part, then also do the two manual UI steps noted below —
--    storage bucket policies are easiest to set from the dashboard.)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('qawafil-photos', 'qawafil-photos', true)
on conflict (id) do nothing;

create policy "qawafil_photos_public_read" on storage.objects
  for select to anon using (bucket_id = 'qawafil-photos');
create policy "qawafil_photos_anon_upload" on storage.objects
  for insert to anon with check (bucket_id = 'qawafil-photos');
create policy "qawafil_photos_anon_delete" on storage.objects
  for delete to anon using (bucket_id = 'qawafil-photos');
