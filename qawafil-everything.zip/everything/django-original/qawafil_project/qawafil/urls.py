from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls.i18n import i18n_patterns
from django.urls import path, include
from django.views.i18n import set_language

urlpatterns = [
    path("i18n/setlang/", set_language, name="set_language"),
]

# صفحة 404 مخصصة بهوية الجمعية (تُفعَّل عندما DEBUG=False)
handler404 = "pages.views.handler404"

# جميع صفحات المحتوى تُسبق تلقائياً بـ /ar/ أو /fr/ حسب اللغة المختارة.
# All content pages are automatically prefixed with /ar/ or /fr/.
urlpatterns += i18n_patterns(
    path("", include("pages.urls")),
    prefix_default_language=True,
)

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.BASE_DIR / "static")
