"""
إعدادات مشروع الموقع الرسمي لجمعية قوافل الخير.
Django settings for the Qawafil Al Khair official website.
"""
from pathlib import Path
import os

from django.core.exceptions import ImproperlyConfigured

BASE_DIR = Path(__file__).resolve().parent.parent

# --------------------------------------------------------------------------
# الأمان الأساسي / Core security
# --------------------------------------------------------------------------
# آمن افتراضياً: DEBUG مُطفأ ما لم يُفعَّل صراحة محلياً عبر متغير البيئة.
# Secure by default: DEBUG is OFF unless explicitly enabled for local dev.
DEBUG = os.environ.get("QAWAFIL_DEBUG", "0") == "1"

_INSECURE_DEFAULT_KEY = "dev-only-secret-key-change-this-before-production-cchangeme"
SECRET_KEY = os.environ.get("QAWAFIL_SECRET_KEY", _INSECURE_DEFAULT_KEY)

if not DEBUG and SECRET_KEY == _INSECURE_DEFAULT_KEY:
    raise ImproperlyConfigured(
        "يجب ضبط متغير البيئة QAWAFIL_SECRET_KEY بمفتاح سرّي حقيقي وفريد قبل "
        "النشر (DEBUG=False). لا تستخدم المفتاح الافتراضي في الإنتاج أبداً.\n"
        "You must set the QAWAFIL_SECRET_KEY environment variable to a real, "
        "unique secret before deploying (DEBUG=False). Never use the default "
        "key in production. Generate one with:\n"
        "  python -c \"from django.core.management.utils import "
        "get_random_secret_key; print(get_random_secret_key())\""
    )

# في وضع التطوير المحلي فقط يُسمح بأي مضيف؛ في الإنتاج يجب تحديد النطاقات
# الفعلية صراحة عبر متغير البيئة (مثال: "qawafilalkhair.mr,www.qawafilalkhair.mr").
# Wildcard hosts are only allowed in local DEBUG mode; production must list
# its real domain(s) explicitly via the environment variable.
if DEBUG:
    ALLOWED_HOSTS = os.environ.get("QAWAFIL_ALLOWED_HOSTS", "*").split(",")
else:
    _hosts_env = os.environ.get("QAWAFIL_ALLOWED_HOSTS", "")
    if not _hosts_env:
        raise ImproperlyConfigured(
            "يجب ضبط متغير البيئة QAWAFIL_ALLOWED_HOSTS بأسماء النطاقات "
            "الحقيقية للموقع قبل النشر (مثال: "
            "QAWAFIL_ALLOWED_HOSTS=qawafilalkhair.mr,www.qawafilalkhair.mr). "
            "استخدام '*' في الإنتاج غير آمن (هجمات Host header).\n"
            "You must set QAWAFIL_ALLOWED_HOSTS to your real domain name(s) "
            "before deploying. A wildcard is not safe in production (Host "
            "header attacks)."
        )
    ALLOWED_HOSTS = [h.strip() for h in _hosts_env.split(",") if h.strip()]

# --------------------------------------------------------------------------
# التطبيقات / Installed apps
# لا حاجة لحسابات مستخدمين أو قواعد بيانات دفع: الموقع تعريفي بالكامل.
# --------------------------------------------------------------------------
INSTALLED_APPS = [
    "django.contrib.staticfiles",
    "pages",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    # يضيف رأس Content-Security-Policy وPermissions-Policy (لا تُضيفهما
    # SecurityMiddleware افتراضياً، ولا حاجة لحزمة خارجية — انظر pages/middleware.py)
    "pages.middleware.SecurityHeadersMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.locale.LocaleMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

# --------------------------------------------------------------------------
# تحصين إضافي للأمان (رؤوس HTTP، الجلسات، الكوكيز)
# Hardened security headers, sessions & cookies
# --------------------------------------------------------------------------
# الحماية من Clickjacking (بالإضافة إلى frame-ancestors في CSP أدناه)
X_FRAME_OPTIONS = "DENY"

# منع المتصفح من "تخمين" نوع الملف (MIME sniffing)
SECURE_CONTENT_TYPE_NOSNIFF = True

# لا تُفصح الصفحة عن عنوان المصدر الكامل عند الانتقال لموقع آخر
SECURE_REFERRER_POLICY = "strict-origin-when-cross-origin"
SECURE_CROSS_ORIGIN_OPENER_POLICY = "same-origin"

# كوكيز الجلسة وCSRF: HttpOnly دائماً، وSameSite=Lax، وSecure في الإنتاج فقط
# (لا تُفعَّل Secure في DEBUG المحلي لأنه غالباً بدون HTTPS)
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"
CSRF_COOKIE_HTTPONLY = True
CSRF_COOKIE_SAMESITE = "Lax"
SESSION_COOKIE_SECURE = not DEBUG
CSRF_COOKIE_SECURE = not DEBUG

# HSTS وإعادة التوجيه لـHTTPS: في الإنتاج فقط. إن كان الموقع خلف وسيط عكسي
# (nginx/Load Balancer) يُنهي TLS، فعّل أيضاً QAWAFIL_BEHIND_PROXY=1 حتى
# يعرف Django أن الطلب أصلاً كان عبر HTTPS (وإلا يدخل في حلقة إعادة توجيه).
if not DEBUG:
    SECURE_SSL_REDIRECT = os.environ.get("QAWAFIL_SSL_REDIRECT", "1") == "1"
    SECURE_HSTS_SECONDS = 31536000  # سنة كاملة، القيمة المعيارية الموصى بها
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True
    if os.environ.get("QAWAFIL_BEHIND_PROXY", "0") == "1":
        SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
else:
    SECURE_SSL_REDIRECT = False

ROOT_URLCONF = "qawafil.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.template.context_processors.static",
                "pages.context_processors.site_context",
            ],
        },
    },
]

WSGI_APPLICATION = "qawafil.wsgi.application"
ASGI_APPLICATION = "qawafil.asgi.application"

# لا توجد قاعدة بيانات مطلوبة فعلياً (لا حسابات، لا دفع إلكتروني)
# لكن نبقي sqlite افتراضياً لتوافق Django الداخلي (الجلسات ونحوها).
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

# --------------------------------------------------------------------------
# اللغات: العربية (أساسية) والفرنسية فقط — بدون الإنجليزية
# Languages: Arabic (primary) and French only — no English
# --------------------------------------------------------------------------
LANGUAGE_CODE = "ar"

LANGUAGES = [
    ("ar", "العربية"),
    ("fr", "Français"),
]

# نعتمد نظام محتوى ثنائي اللغة خاصاً بالمشروع (pages/content.py)
# بدلاً من ملفات ترجمة gettext المُجمَّعة (.mo)، لتفادي الاعتماد على أدوات
# gettext الخارجية ولتسهيل تحديث النصوص لاحقاً (انظر البند 34 من المواصفات).
USE_I18N = True
USE_L10N = True
USE_TZ = True
TIME_ZONE = "Africa/Nouakchott"

LOCALE_PATHS = [BASE_DIR / "locale"]

# --------------------------------------------------------------------------
# الملفات الثابتة / Static files
# --------------------------------------------------------------------------
STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR / "static"]
STATIC_ROOT = BASE_DIR / "staticfiles"

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# --------------------------------------------------------------------------
# معلومات الجمعية الرسمية (مصدر واحد للحقيقة تُستخدم في القوالب وSEO)
# Official association info (single source of truth for templates & SEO)
# --------------------------------------------------------------------------
ASSOCIATION = {
    "name_ar": "جمعية قوافل الخير",
    "name_fr": "Association Qawafil Al Khair",
    "phone": "+222 34330001",
    "phone_display": "34 33 00 01",
    "whatsapp_number": "22234330001",  # بصيغة دولية بدون + أو مسافات لرابط wa.me
    "email": "kawafilalkhair07@gmail.com",
    "facebook_url": "https://www.facebook.com/share/18SeC4YKWb/",
    "address_ar": "تيارت – المقاطعة الشمالية – موريتانيا",
    "address_fr": "Teyarett – Moughataa du Nord – Mauritanie",
    "hq_ar": "نواكشوط",
    "hq_fr": "Nouakchott",
}
