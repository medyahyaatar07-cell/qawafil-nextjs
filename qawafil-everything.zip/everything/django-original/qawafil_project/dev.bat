@echo off
REM Quick local run for Windows Command Prompt (cmd.exe).
REM Sets local dev mode automatically, then runs migrate + the dev server.
REM Local development only - never used in production.
REM
REM Usage: from inside the qawafil_project folder, run: dev.bat

set QAWAFIL_DEBUG=1
echo QAWAFIL_DEBUG=1 (local dev mode only - not used in production)

python manage.py migrate
if errorlevel 1 (
    echo migrate failed - see the error above.
    exit /b 1
)

python manage.py runserver
