#!/usr/bin/env python
"""نقطة تشغيل مشروع جمعية قوافل الخير / Point d'entrée du projet Qawafil Al Khair."""
import os
import sys


def main():
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "qawafil.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "تعذر استيراد Django. تأكد من تثبيت الحزم عبر: "
            "pip install -r requirements.txt"
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
