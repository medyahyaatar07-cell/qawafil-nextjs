from django.http import Http404
from django.shortcuts import render

from .content import get_content, get_work_areas, get_work_area


def _lang(request) -> str:
    code = getattr(request, "LANGUAGE_CODE", "ar") or "ar"
    return code if code in ("ar", "fr") else "ar"


def home(request):
    lang = _lang(request)
    content = get_content(lang)
    all_areas = get_work_areas(lang)
    # لمحة سريعة في الرئيسية: نعرض أولاً المجالات التي تتوفر لها صور حقيقية
    teaser = [a for a in all_areas if a["has_media"]] + [a for a in all_areas if not a["has_media"]]
    context = {
        "page_id": "home",
        "work_areas": teaser[:4],
        "meta_title": content["hero"]["eyebrow"] + " — " + content["hero"]["title"],
        "meta_description": content["meta"]["site_description"],
        "og_type": "website",
    }
    return render(request, "pages/home.html", context)


def about(request):
    lang = _lang(request)
    content = get_content(lang)
    context = {
        "page_id": "about",
        "meta_title": content["about"]["title"] + " — " + content["meta"]["site_title"],
        "meta_description": content["about"]["intro"],
        "og_type": "website",
    }
    return render(request, "pages/about.html", context)


def work_list(request):
    lang = _lang(request)
    content = get_content(lang)
    context = {
        "page_id": "work",
        "work_areas": get_work_areas(lang),
        "meta_title": content["work"]["title"] + " — " + content["meta"]["site_title"],
        "meta_description": content["work"]["subtitle"],
        "og_type": "website",
    }
    return render(request, "pages/work_list.html", context)


def work_detail(request, slug):
    lang = _lang(request)
    area = get_work_area(lang, slug)
    if area is None:
        raise Http404("مجال العمل غير موجود / Domaine introuvable")
    content = get_content(lang)
    context = {
        "page_id": "work-detail",
        "area": area,
        "meta_title": area["title"] + " — " + content["meta"]["site_title"],
        "meta_description": area["summary"],
        "og_type": "article",
        "og_image": area.get("image"),
    }
    return render(request, "pages/work_detail.html", context)


def donate(request):
    lang = _lang(request)
    content = get_content(lang)
    context = {
        "page_id": "donate",
        "meta_title": content["donate"]["title"] + " — " + content["meta"]["site_title"],
        "meta_description": content["donate"]["text"].split("\n")[0],
        "og_type": "website",
    }
    return render(request, "pages/donate.html", context)


def contact(request):
    lang = _lang(request)
    content = get_content(lang)
    context = {
        "page_id": "contact",
        "meta_title": content["contact"]["title"] + " — " + content["meta"]["site_title"],
        "meta_description": content["contact"]["text"].split("\n")[0],
        "og_type": "website",
    }
    return render(request, "pages/contact.html", context)


def handler404(request, exception=None):
    lang = _lang(request)
    content = get_content(lang)
    context = {
        "page_id": "404",
        "meta_title": content["not_found"]["title"],
        "meta_description": content["not_found"]["text"],
    }
    return render(request, "pages/404.html", context, status=404)
