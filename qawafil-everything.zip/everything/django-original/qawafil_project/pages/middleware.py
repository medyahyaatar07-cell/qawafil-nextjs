# -*- coding: utf-8 -*-
"""
رؤوس أمان إضافية (Content-Security-Policy وPermissions-Policy).

Django's built-in ``django.middleware.security.SecurityMiddleware`` covers
HSTS, the SSL redirect, ``X-Content-Type-Options`` and ``Referrer-Policy``
(all configured via settings.py). It does **not** ship a Content-Security-Policy
header out of the box, and pulling in a third-party package (e.g. django-csp)
was not possible in the offline environment this project was built in — so
this tiny, dependency-free middleware provides it directly.

السياسة مبنية خصيصاً على ما يحمّله هذا الموقع فعلياً (لا قالب عام جاهز):
خطوط Google Fonts فقط من مصدر خارجي، وكل شيء آخر (CSS/JS/الصور/الفيديو)
من نفس النطاق. لا سكربتات خارجية، لا إعلانات، لا تتبّع طرف ثالث.
The policy is tailored to exactly what this site loads (not a generic
boilerplate): Google Fonts is the only external origin; everything else
(CSS/JS/images/video) is same-origin. No third-party scripts, ads, or
trackers of any kind.
"""

CONTENT_SECURITY_POLICY = "; ".join(
    [
        "default-src 'self'",
        # لا سكربتات خارجية إطلاقاً. سكربت JSON-LD (application/ld+json) في
        # base.html لا يخضع لقيود script-src لأنه ليس نوع MIME تنفيذياً.
        "script-src 'self'",
        # يُسمح بأنماط inline لأن التصميم يعتمد بعض style="" داخل القوالب،
        # بالإضافة لخطوط Google Fonts فقط كمصدر خارجي وحيد للأنماط.
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        "font-src 'self' https://fonts.gstatic.com",
        "img-src 'self' data:",
        "media-src 'self'",
        "connect-src 'self'",
        # منع أي جهة من تضمين الموقع داخل إطار (iframe) — طبقة حماية إضافية
        # فوق X-Frame-Options: DENY المضبوطة في الإعدادات.
        "frame-ancestors 'none'",
        "frame-src 'none'",
        "object-src 'none'",
        "base-uri 'self'",
        "form-action 'self'",
    ]
)

# لا حاجة للموقع لأي من هذه الصلاحيات (كاميرا، ميكروفون، موقع جغرافي...)
# فتُغلَق كلها صراحة دفاعاً في العمق.
PERMISSIONS_POLICY = ", ".join(
    [
        "accelerometer=()",
        "camera=()",
        "geolocation=()",
        "gyroscope=()",
        "magnetometer=()",
        "microphone=()",
        "payment=()",
        "usb=()",
        "interest-cohort=()",  # يمنع تتبّع FLoC/Topics الإعلاني من جوجل
    ]
)


class SecurityHeadersMiddleware:
    """يضيف Content-Security-Policy وPermissions-Policy لكل استجابة."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response.setdefault("Content-Security-Policy", CONTENT_SECURITY_POLICY)
        response.setdefault("Permissions-Policy", PERMISSIONS_POLICY)
        return response
