from django.urls import path

from . import views

app_name = "pages"

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("work/", views.work_list, name="work_list"),
    path("work/<slug:slug>/", views.work_detail, name="work_detail"),
    path("donate/", views.donate, name="donate"),
    path("contact/", views.contact, name="contact"),
]
