from django.conf import settings
from django.urls import translate_url

from .content import get_content


def site_context(request):
    """
    يُتيح لكل القوالب الوصول إلى: محتوى اللغة الحالية، اتجاه الصفحة (rtl/ltr)،
    معلومات الجمعية الرسمية، ورابط تبديل اللغة الحالي (لنفس الصفحة).
    """
    lang_code = getattr(request, "LANGUAGE_CODE", "ar") or "ar"
    if lang_code not in ("ar", "fr"):
        lang_code = "ar"
    content = get_content(lang_code)
    other_lang = "fr" if lang_code == "ar" else "ar"

    try:
        alternate_url = translate_url(request.path, other_lang)
    except Exception:
        alternate_url = "/" + other_lang + "/"

    return {
        "LANG_CODE": lang_code,
        "OTHER_LANG_CODE": other_lang,
        "DIR": content["dir"],
        "T": content,
        "ASSOCIATION": settings.ASSOCIATION,
        "CURRENT_PATH": request.path,
        "ALTERNATE_URL": alternate_url,
    }
