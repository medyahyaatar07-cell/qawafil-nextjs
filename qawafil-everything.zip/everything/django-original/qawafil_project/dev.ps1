# Quick local run for Windows PowerShell.
# Sets local dev mode automatically, then runs migrate + the dev server,
# so you never have to remember to set the env var by hand each time.
#
# Usage: from inside the qawafil_project folder, run:
#   .\dev.ps1
#
# If you see an error like "running scripts is disabled on this system" or
# "is not digitally signed" / "UnauthorizedAccess", PowerShell's script
# execution policy is blocking unsigned .ps1 files (a common default, not a
# problem with this file). Fastest fix, no permanent setting changed:
#   powershell -ExecutionPolicy Bypass -File .\dev.ps1
# Or, to allow .\dev.ps1 directly in just this window:
#   Set-ExecutionPolicy -Scope Process RemoteSigned
# then run .\dev.ps1 again. If that's blocked too (some work computers lock
# this down), just use dev.bat instead - same result, no such restriction.

$env:QAWAFIL_DEBUG = "1"

Write-Host "QAWAFIL_DEBUG=1 (local dev mode only - not used in production)" -ForegroundColor Yellow

python manage.py migrate
if ($LASTEXITCODE -ne 0) {
    Write-Host "migrate failed - see the error above." -ForegroundColor Red
    exit $LASTEXITCODE
}

python manage.py runserver
