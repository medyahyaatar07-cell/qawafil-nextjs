/*
 * QAWAFIL MOTION IDENTITY — منطق الحركة الموحّد للموقع
 * كل الحركات هنا تعتمد على transform/opacity فقط لتفادي إعادة الرسم الثقيلة،
 * وتحترم prefers-reduced-motion بالكامل (اعتماداً أيضاً على CSS).
 */
(function () {
  "use strict";

  var REDUCED_MOTION = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------------------------------------------------------------
   * 1) الرأس الثابت: يتقلص بأناقة عند التمرير دون أن يختفي
   * ------------------------------------------------------------------- */
  var header = document.getElementById("site-header");
  if (header) {
    var onScroll = function () {
      if (window.scrollY > 24) {
        header.classList.add("is-scrolled");
      } else {
        header.classList.remove("is-scrolled");
      }
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* ---------------------------------------------------------------------
   * 2) قائمة الهاتف المنسدلة
   * ------------------------------------------------------------------- */
  var openBtn = document.getElementById("nav-open-btn");
  var closeBtn = document.getElementById("nav-close-btn");
  var mobileNav = document.getElementById("mobile-nav");

  function openMobileNav() {
    if (!mobileNav) return;
    mobileNav.classList.add("is-open");
    openBtn && openBtn.setAttribute("aria-expanded", "true");
    var firstLink = mobileNav.querySelector("a");
    firstLink && firstLink.focus();
    document.body.style.overflow = "hidden";
  }
  function closeMobileNav() {
    if (!mobileNav) return;
    mobileNav.classList.remove("is-open");
    openBtn && openBtn.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
  }
  openBtn && openBtn.addEventListener("click", openMobileNav);
  closeBtn && closeBtn.addEventListener("click", closeMobileNav);
  mobileNav && mobileNav.addEventListener("click", function (e) {
    if (e.target.tagName === "A") closeMobileNav();
  });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeMobileNav();
  });

  /* ---------------------------------------------------------------------
   * 3) Reveal عند التمرير — ظهور ناعم لعناصر الأقسام
   * ------------------------------------------------------------------- */
  var revealEls = document.querySelectorAll(".reveal");
  if (revealEls.length) {
    if ("IntersectionObserver" in window && !REDUCED_MOTION) {
      var io = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-visible");
              io.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
      );
      revealEls.forEach(function (el) { io.observe(el); });
    } else {
      revealEls.forEach(function (el) { el.classList.add("is-visible"); });
    }
  }

  /* ---------------------------------------------------------------------
   * 4) مقدمة الشعار المتحركة (Logo Intro) — تظهر مرة واحدة لكل جلسة تصفح،
   *    ولا تحجب المحتوى أكثر من ثوانٍ قليلة، وتُحترم فيها إمكانية التخطي.
   * ------------------------------------------------------------------- */
  var intro = document.getElementById("logo-intro");
  if (intro) {
    var alreadySeen = false;
    try { alreadySeen = sessionStorage.getItem("qawafilIntroSeen") === "1"; } catch (e) { alreadySeen = false; }

    function hideIntro() {
      intro.classList.add("is-hidden");
      try { sessionStorage.setItem("qawafilIntroSeen", "1"); } catch (e) {}
      setTimeout(function () { intro.remove(); }, 650);
    }

    if (alreadySeen || REDUCED_MOTION) {
      hideIntro();
    } else {
      var video = intro.querySelector("video");
      var maxTimer = setTimeout(hideIntro, 2600); // لا ننتظر أكثر من هذا مهما حدث
      if (video) {
        video.addEventListener("ended", function () { clearTimeout(maxTimer); hideIntro(); });
        video.play().catch(function () { hideIntro(); });
      }
      var skipBtn = intro.querySelector(".skip-intro-btn");
      skipBtn && skipBtn.addEventListener("click", function () {
        clearTimeout(maxTimer);
        hideIntro();
      });
    }
  }

  /* ---------------------------------------------------------------------
   * 5) انتقال الصفحات — ستارة بصرية قصيرة مستوحاة من إيقاع اللوجو أنيميشن
   *    (تعمل فقط بين صفحات الموقع نفسه، ولا تُفعَّل مع تفضيل تقليل الحركة)
   * ------------------------------------------------------------------- */
  var veil = document.getElementById("page-veil");
  if (veil && !REDUCED_MOTION) {
    document.addEventListener("click", function (e) {
      var link = e.target.closest("a");
      if (!link) return;
      if (link.target === "_blank" || link.hasAttribute("download")) return;
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      var href = link.getAttribute("href");
      if (!href || href.indexOf("#") === 0 || href.indexOf("mailto:") === 0 || href.indexOf("tel:") === 0) return;
      if (link.origin !== window.location.origin) return;
      if (link.pathname === window.location.pathname) return;

      e.preventDefault();
      veil.classList.add("animate-in");
      setTimeout(function () { window.location.href = href; }, 380);
    });

    window.addEventListener("pageshow", function (event) {
      if (event.persisted) {
        veil.classList.remove("animate-in", "animate-out");
      }
    });
  }
})();
