#!/usr/bin/env bash
# Quick local run for macOS/Linux.
# Sets local dev mode automatically, then runs migrate + the dev server.
#
# Usage: from inside the qawafil_project folder, run:
#   bash dev.sh
# or (after chmod +x dev.sh):
#   ./dev.sh

set -e
export QAWAFIL_DEBUG=1
echo "QAWAFIL_DEBUG=1 (local dev mode only - not used in production)"

python manage.py migrate
python manage.py runserver
